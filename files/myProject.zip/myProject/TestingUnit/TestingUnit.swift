//
//  TestingUnit.swift
//  TestingUnit
//
//  Created by Игорь Крысин on 27.02.2025.
//

import Testing

struct TestingUnit {

    @Test func testSumm() {
          // Создаем экземпляр Stack
        var stack = Stack<Double>()
        stack.appendMult([3, 2, 4.6], isReverse: false)
          // Проверяем, что функция summ возвращает правильный результат
        #expect(stack.showStack() == [3, 2, 4.6])
        
        stack.pop()
        #expect(stack.showStack() == [3, 2])
        
        stack.pop()
        #expect(stack.showStack() == [3])
        
        stack.pop()
        #expect(stack.showStack() == [])
        
        stack.appendMult([3, 2, 4.6], isReverse: true)
        
        #expect(stack.showStack() == [4.6, 2, 3])
        
        
        
        //проверяю добавление наоборот
//        stack.appendMult([3, 2, 4.6], isReverse: true)
//        #expect(stack.showStack() == [4.6, 2.0, 3])
      }

}
