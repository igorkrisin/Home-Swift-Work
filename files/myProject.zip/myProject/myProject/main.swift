import Foundation

struct Stack<T> {
    var stack: [T] = []
    // count func any
    func countAny() -> Int {
        var sum: Int = 0
        for _ in self.stack {
            sum += 1
        }
        return sum
    }
    // 5 printStack - печать стека
    func printStack() {
        print(self.stack)
    }
    //append func Any
    mutating func appendSoft(_ element: T) {
        self.stack = self.stack + [element]
    }
    //remive func
    mutating func removeElementsAny(index: Int) -> [T] {
        var nextArray: [T] = []
        let numbersOfElements: Int = countAny()
        if numbersOfElements == 0 {
            print("Массив пустой, введите заполненный чем-либо")
        }
        if numbersOfElements < abs(index) {
            print("кол-во элементов в массиве: \(numbersOfElements) а вы вводите идекс заходящий за пределы массива")
        } else {
            for i in 0 ..< numbersOfElements {
                if i != abs(index) {
                    nextArray.append(self.stack[i])
                }
            }
        }
        return nextArray
    }
    //func размер стэка
    func size() -> Int {
        return countAny()
    }
    //pop - удаляется последний элемент
    // стека и он же возвращается из функции: нпаример  - pop([1, 2, 3)
    //(а стeк исменился и стал [1, 2]. Если удалять нечего - возвращаем nil
    mutating func pop() -> T? {
        if self.countAny() != 0 {
            let lastIndex = self.countAny() - 1
            let lastElement = self.stack[lastIndex]
            self.stack = self.removeElementsAny(index: lastIndex)
            return lastElement
        } else {
            return nil
        }
    }
    //3 push - добавление элемнта на вершину стэка (ничего не возврашает)
    mutating func push(_ element: T) {
        self.appendSoft(element)
    }
    // 4 peek - возврат верхнего(последнего элемнета стэка)если последнего элемента нет - возвращаем nil
    func peek() -> T? {
        if self.countAny() != 0 {
            let lastIndex = self.countAny() - 1
            let lastElement = self.stack[lastIndex]
            return lastElement
        } else {
            return nil
        }
    }
    //6 appendMult- добавляет несколько элементов на стэк (принимает не пустой массив элементы которого по порядку укладывает на стэк) - задание со *
    //MARK: добавить в данную функцию булевый флаг который будет складывать на стэк элементы из массива начиная с его конца. Например : appendMult([1,2,3], isReverse: true) - складывает на вершину стэка 3 2 1 (в таком порядке, если appendMult([1,2,3], isReverse: false) - 1 2 3 по попадут на стэк в таком порядке
    mutating func appendMult(_ elements: [T], isReverse: Bool) {
        if isReverse == false {
            self.stack = self.stack + elements
        } else {
            for i in 0 ..< self.countAny() {
                self.appendSoft(self.stack[self.countAny() - 1 - i])
            }
        }
        
    }
    
    func showStack() -> [T] {
        return self.stack
    }
    
}
// test:
var myStack: Stack = Stack<Any>()
//myStack.appendSoft(12)
//myStack.appendSoft(3)
//
//myStack.printStack()
//
//print(myStack.pop())
//print(myStack.pop())
//myStack.printStack()
//print(myStack.pop())
//
//myStack.push(15)
//myStack.push(23)
//myStack.printStack()
//
//myStack.peek()
//print(myStack.peek())

myStack.appendMult(["d", "s", 4.6], isReverse: true)

myStack.printStack()

//
//myStack.appendMult([1, 2, 3], isReverse: false)
//myStack.printStack()


